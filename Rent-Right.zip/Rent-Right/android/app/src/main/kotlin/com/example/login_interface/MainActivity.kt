package com.example.login_interface

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
