enum BuildingType {
  house,
  apartment,
  other,
}
